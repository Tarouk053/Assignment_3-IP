var nameError = document.getElementById('name-error');
var phoneError = document.getElementById('phone-error');
var emailError = document.getElementById('email-error');
var passError = document.getElementById('pass-error');
var noError = document.getElementById('no-error');
var submitError = document.getElementById('submit-error');

function validateName(){
    var name = document.getElementById('contactname').value;

    if(name.length == 0){
        nameError.innerHTML= 'Name is required';
        return false;
    }
    if(!name.match(/^[A-Za-z]*\s{1}[A-Za-z]*$/)){
        nameError.innerHTML= 'Write full name';
        return false;
    }
    nameError.innerHTML='<i class="fas fa-check-circle"></i>';
    return true;
}

function validatePhone(){
    var phone = document.getElementById('contactphone').value;

    if(phone.length == 0){
        phoneError.innerHTML= 'phone no. is required';
        return false;
    }
    
    if(phone.length !== 11){
        phoneError.innerHTML= 'phone no. should be 11 digits';
        return false;
    }
    
    if(!phone.match(/^[0-9]{11}$/)){
        phoneError.innerHTML= 'Only digits';
        return false;
    }
    phoneError.innerHTML='<i class="fas fa-check-circle"></i>';
    return true;
}

function validateEmail(){
    var email = document.getElementById('contactemail').value;

    if(email.length == 0){
        emailError.innerHTML= 'Email is required'
        return false;
    }
    if(!email.match(/^[A-Za-z\._\-[0-9]*[@][A-Za-z]*[\.][a-z]{2,4}$/)){
        emailError.innerHTML = 'Email Invalid'
        return false;
    }
    emailError.innerHTML = '<i class="fas fa-check-circle"></i>';
    return true;
}

function validatePass(){
    var pass = document.getElementById('contactpass').value;

    if(pass.length == 0){
        passError.innerHTML= 'Password is required'
        return false;
    }
    if(!pass.match(/^[a-zA-Z0-9 !@#$%^&*]{6,16}$/)){
        passError.innerHTML = 'Pass must be more than 6 char.'
        return false;
    }
    passError.innerHTML = '<i class="fas fa-check-circle"></i>';
    return true;
}

function validateNo(){
    var no = document.getElementById('contactno').value;

    if(no.length == 0){
        noError.innerHTML= 'ID no. is required';
        return false;
    }
    
    if(no.length !== 14){
        noError.innerHTML= 'ID no. should be 14 digits';
        return false;
    }
    
    if(!no.match(/^[0-9]{14}$/)){
        noError.innerHTML= 'Only digits';
        return false;
    }
    noError.innerHTML='<i class="fas fa-check-circle"></i>';
    return true;
}

function validateForm(){
    if(!validateName() || !validatePhone() || !validateEmail() || !validateNo() ||!validatePass() ){
        submitError.style.display = 'block';
        submitError.innerHTML = 'Please resolve the error to submit';
        setTimeout(function(){submitError.style.display = 'none';}, 3000);
        return false;
    }

    let name = document.getElementById("contactname").value;
    let phone = document.getElementById("contactphone").value;
    let email = document.getElementById("contactemail").value;
    let pass = document.getElementById("contactpass").value;
    let no = document.getElementById("contactno").value;
    console.log(name);    
    console.log(phone);
    console.log(email);
    console.log(pass);
    console.log(no);
}
    
